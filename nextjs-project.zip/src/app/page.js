import Image from "next/image"


export default function Home() {
  return (
    <div>
      <Image src="/home-hero-img.png"
        width={300}
        height={400}
        alt="รูป hero"
        className="w-full db"
      />
      <h1>My First To-do app</h1>
    </div>
  )
}